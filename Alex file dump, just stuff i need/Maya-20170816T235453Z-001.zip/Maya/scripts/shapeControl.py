import maya.cmds as cmds
import maya.mel as mel, os

def shapeControlUI():

    global my_window
    UIDir = str(os.path.dirname(__file__)).replace("\\", "/")
    my_window = cmds.loadUI(uiFile = UIDir +'/shapeControlUI.ui')

    try:
        my_window.close()
        my_window.deleteLater()
    except: pass
    cmds.showWindow(my_window)
    cmds.window(my_window, edit = True, topLeftCorner = (200,200))



jntSel = []
def jntSelection ():
    allObjects = cmds.ls(sl=True)
    cmds.textField('parentJointTF', edit=True, text=allObjects[0])
    global jntSel 
    jntSel = cmds.textField('parentJointTF', text= True, query=True )


def crvSelection ():
    allCurve = cmds.ls(sl=True)
    cmds.textField('parentCurveTF', edit=True, text= allCurve[0])

def lastSelection ():
    print str (jntSel)
    cmds.textField('jointShapeTF', edit=True, text = jntSel)


def remSelection ():
    allShapes = cmds.ls(sl=True)
    cmds.textField('jointShapeTF', edit=True, text=allShapes[0])

def dupSelection ():
    allShapes = cmds.ls(sl=True)
    cmds.textField('dupJointTF', edit=True, text=allShapes[0])


def parentShape ():
    parentJoint = cmds.textField('parentJointTF', text= True, query=True )
    parentShape = cmds.textField('parentCurveTF', text= True, query=True )
    selShape = cmds.listRelatives( parentShape, shapes=True )
    cmds.parent( selShape[0], parentJoint, shape=True, relative=True )
    cmds.delete( parentShape)
    cmds.select( cl=True)


def removeParent ():
    parentJntShape = cmds.textField('jointShapeTF', text= True, query=True )
    jntShape = cmds.listRelatives( parentJntShape, shapes=True )
    grpName = jntShape[0].split('S')
    newGroup = cmds.group(name = grpName[0],empty=True, world=True)
    cmds.parent( jntShape[0], newGroup, shape=True, relative=True )
    cmds.select( cl=True)

def duplicateControl():
    #find the name of the joint by typing in or selecting.  work out which is the joint and get to its shape
    dupJoint = cmds.textField('dupJointTF', text= True, query=True )
    dupShape = cmds.listRelatives( dupJoint, shapes=True )
    #create a group for the shape node to noow sit under as it transfers from the joint
    grpdupName = dupShape[0].split('S')
    newGroup = cmds.group(name = grpdupName[0],empty=True, world=True)
    cmds.parent( dupShape[0], newGroup, shape=True, relative=True )
    #duplicate the selected control
    cmds.duplicate ( dupShape, name = str (newGroup) + 'COPY' )
    # re wire the original back to how it was.


    cmds.parent( dupShape, dupJoint, shape=True, relative=True )
    cmds.delete( newGroup)
    cmds.select( cl=True)

