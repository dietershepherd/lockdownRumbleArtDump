Description 

Use this script in riging process for adding controllers to them.

Color:---------------------------------------------------------------
   Use color slider to change color of controllers and 
   any other things in your scene.

Lock & hide:----------------------------------------------------------
   Lock or hide translate, rotate, scale and visibility 
   of controllers and any other things in your scene.  
   Get lock and hide info from existing object in your scene by pressing 
   Get from selected button then by Apply to selected button you can 
   Apply these info to another one.

mirror :--------------------------------------------------------------
   mirror controllers shapes from one side to another.

Shapes:---------------------------------------------------------------
   Create a controller shape by simply pressing a button and if you have 
   something selected in scene the controller's shape will snape to that.
   and if create up node checkbox turns on then you could group controller 
   by itself and use it as an up node.

Slider maker:---------------------------------------------------------
   Press slider maker button to bring back slider maker 
   window then set the height and width value of slider�s
   border and set value of slider�s handle and finally press 
   make slider button.   

Combine shapes:-------------------------------------------------------
   Select childe shape and parent shape then press 
   combine shape button to combine these two to one.

Freeze transformations:-----------------------------------------------
   By using freeze transformations button you are able to 
   freeze locked transformations of controllers and 
   you don�t have to unlock them before freezing them.

----------------------------------------------------------------------
How to install 
  Put kk_icons folder in your prefs/icons folder, put the kk_controllers.mel 
  into your scripts folder then launch Maya in command line type 
  kk_controllers and hit enter.




